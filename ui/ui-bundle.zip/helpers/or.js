module.exports = (...args) => args.slice(0, -1).find(Boolean);
