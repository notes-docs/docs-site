'use strict'

// 它返回当前年份作为字符串格式
module.exports = () => new Date().getFullYear().toString()
