'use strict'

// 一个简单的箭头函数，它接收两个参数 a 和 b，并返回一个布尔值，表示 a 和 b 是否不相等。
// 具体来说，如果 a 和 b 不相等，则返回 true，否则返回 false。
module.exports = (a, b) => a !== b
