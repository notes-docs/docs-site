(function () {
  var navToggle = document.querySelector('[data-nav-toggle]');
  var navPanelRoot = document.querySelector('[data-sidebar-root]');
  var themeToggle = document.querySelector('[data-theme-toggle]');
  var root = document.documentElement;

  if (navToggle && navPanelRoot) {
    navToggle.addEventListener('click', function () {
      var isOpen = navPanelRoot.getAttribute('data-open') === 'true';
      var nextState = isOpen ? 'false' : 'true';
      navPanelRoot.setAttribute('data-open', nextState);
      navToggle.setAttribute('aria-expanded', nextState);
      document.body.style.overflow = nextState === 'true' ? 'hidden' : '';
    });
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      var nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      root.dataset.theme = nextTheme;
      window.localStorage.setItem('lucode-theme', nextTheme);
    });
  }
})();
